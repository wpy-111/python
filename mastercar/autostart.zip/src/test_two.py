from widgets import Servo_pwm
import time
a = Servo_pwm(2)
while True:
    a.servocontrol(180,50)
    time.sleep(2)
    a.servocontrol(0,50)
    time.sleep(3)
