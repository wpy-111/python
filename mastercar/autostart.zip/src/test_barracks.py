from driver import *
from obstacle import *
driver = Driver()
driver.stop()
time.sleep(0.5)

driver.driver_run(40,40)
time.sleep(0.6)
driver.driver_run(0, -50)
time.sleep(0.8)
driver.driver_run(-40, -40)
time.sleep(0.5)
driver.stop()
for i in range(0, 4):
    Lightwork(2, "red")
    time.sleep(0.5)
    Lightwork(2, "off")
driver.driver_run(40, 40)
time.sleep(0.4)
driver.driver_run(0, 50)
time.sleep(0.65)
driver.stop()
