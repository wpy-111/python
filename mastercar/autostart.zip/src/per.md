

# ZU3A

Loading model: models/cruise
index = 0  score = 0.002533  OK ✔
Each Frame used: 4.6825999999999999ms 

### Model: models/cruise PASSED.

========================================
Loading model: models/blue
index = 1  score = 0.856274  OK ✔
Each Frame used: 19.041250000000002ms 
Model: models/blue PASSED.
========================================
Loading model: models/light
index = 1  score = 0.500109  OK ✔
Each Frame used: 19.080970000000001ms 
Model: models/light PASSED.
========================================
Each Frame used: 27.709289999999999ms 
Model: models/sign_fuse PASSED.



# ZU3B
Loading model: models/cruise
index = 0  score = 0.002533  OK ✔
Each Frame used: 4.7025600000000001ms 

Model: models/cruise PASSED.
========================================
Loading model: models/blue
index = 1  score = 0.856274  OK ✔
Each Frame used: 18.938299999999998ms 
Model: models/blue PASSED.
========================================
Loading model: models/light
index = 1  score = 0.500109  OK ✔
Each Frame used: 18.937850000000001ms 
Model: models/light PASSED.
========================================
Each Frame used: 27.613609999999998ms 
Model: models/sign_fuse PASSED.
========================================